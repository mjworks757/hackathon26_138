import requests

def get_uipath_token(ClientId, ClientSecret, Scope):
    token_url = "https://staging.uipath.com/identity_/connect/token"

    payload = {
        "grant_type": "client_credentials",
        "client_id": ClientId,
        "client_secret": ClientSecret,
        "scope": Scope
    }

    r = requests.post(token_url, data=payload, timeout=10)

    if r.status_code == 200:
        return r.json()["access_token"]
    else:
        raise Exception(f"Token fetch failed: {r.status_code} - {r.text}")