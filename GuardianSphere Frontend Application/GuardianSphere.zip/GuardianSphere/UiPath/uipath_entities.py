import requests

BASE_URL    = "https://staging.uipath.com"
ORG_NAME    = "hackathon26_138"
TENANT_NAME = "DefaultTenant"

def create_entity_record(token: str, data: dict, entity: str):
    url = f"https://staging.uipath.com/hackathon26_138/DefaultTenant/datafabric_/api/EntityService/{entity}/insert"    

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    response = requests.post(url, headers=headers, json=data)

    print("Status :", response.status_code)
    print("Body   :", response.text)

    if response.status_code in [200, 201]:
        return response.json()
    else:
        raise Exception(f"Failed to create record: {response.status_code} - {response.text}")

# def get_EntityRecord_Id(token: str, entity: str, email: str):
#     url = f"https://staging.uipath.com/hackathon26_138/DefaultTenant/datafabric_/api/EntityService/{entity}/read"

#     print(url)
#     headers = {
#         "Authorization": f"Bearer {token}",
#         "Content-Type": "application/json"
#     }

#     response = requests.get(url, headers=headers)
#     data = response.json()
#     filtered = [r for r in data["value"] if r["StudentEmail"].lower() == email.lower()]

#     print("Status :", response.status_code)
#     print("Body   :", response.text)

#     if response.status_code in [200, 201]:
#         return filtered
#     else:
#         raise Exception(f"Failed to create record: {response.status_code} - {response.text}")

# def upload_entity_file(id: str, token: str, uploaded_file, case: str):
#     if case == "ReportCard":
#         url = f"https://staging.uipath.com/hackathon26_138/DefaultTenant/datafabric_/api/Attachment/CaseManagement/{id}/ReportCard"    
#     elif case == "IncidentProof":
#         url = f"https://staging.uipath.com/hackathon26_138/DefaultTenant/datafabric_/api/Attachment/CaseManagement/{id}/IncidentProof"    
    
#     headers = {
#         "Authorization": f"Bearer {token}"
#     }

#     files = {
#         "file": (
#             uploaded_file.name,
#             uploaded_file.getvalue(),
#             uploaded_file.type
#         )
#     }

    # response = requests.post(url, headers=headers, files=files)

    # print("Status :", response.status_code)
    # print("Body   :", response.text)

    # if response.status_code in [200, 201]:
    #     return response.json()
    # else:
    #     raise Exception(f"Failed to create record: {response.status_code} - {response.text}")

def upload_entity_file(
    id: str,
    token: str,
    uploaded_files,
    field_name: str
):
 
    url = (
        f"https://staging.uipath.com/hackathon26_138/"
        f"DefaultTenant/datafabric_/api/Attachment/"
        f"CaseManagement/{id}/{field_name}"
    )
 
    headers = {
        "Authorization": f"Bearer {token}"
    }
 
    files = {
        "file": (
            uploaded_files.name,
            uploaded_files.getvalue(),
            uploaded_files.type
        )
    }
 
    response = requests.post(
        url,
        headers=headers,
        files=files
    )
 
    print("Field :", field_name)
    print("Status:", response.status_code)
    print("Body  :", response.text)
 
    if response.status_code in [200, 201]:
        return response.json()
 
    raise Exception(
        f"Failed upload for {field_name}: "
        f"{response.status_code} - {response.text}"
    )