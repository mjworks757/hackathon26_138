
import streamlit as st
st.title("Teacher Alert")
st.text_input("Child ID")
st.checkbox("Grade Drop")
st.checkbox("Behavior Change")
st.checkbox("Internet Misuse")
st.button("Create Alert")
