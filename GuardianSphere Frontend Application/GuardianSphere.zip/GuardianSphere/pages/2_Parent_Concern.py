
import streamlit as st
import keyring
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
import sys
import os
import uuid


sys.path.append(os.path.join(os.path.dirname(__file__), "UiPath"))
from UiPath.uipath_token import get_uipath_token
from UiPath.uipath_entities import create_entity_record
from UiPath.uipath_entities import get_EntityRecord_Id
from UiPath.uipath_entities import upload_entity_file

tokenVal = get_uipath_token("049bec0a-d959-46ad-8bf1-6a790b70802d","drUU6ZrF^~hk09C5tbc%2%jkUs7?t9Mo#nq69yYC?*8R)scZw^xGXmuVs(@$uo7S","DataFabric.Data.Read DataFabric.Data.Write DataFabric.Schema.Read")

def load_credentials():
    email    = keyring.get_password("StudentEvaluationReport_app", "sender_email")
    password = keyring.get_password("StudentEvaluationReport_app", "sender_password")

    if not email or not password:
        st.error("Credentials not found in Credential Manager.")
        st.info("Run save_credential.py first to store your credentials.")
        st.stop()

    return email, password


st.title("Parent, Child & Teacher Concerns")

child_id = st.text_input("Admission Number")

concern_type = st.selectbox(
    "Concern Type",
    ["Wellness", "Safety", "Career"]
)

description = st.text_area("Description")

payload = {}

# Wellness
if concern_type == "Wellness":
    SENDER_EMAIL, SENDER_PASSWORD = load_credentials()

    st.subheader("Wellness Details")
    with st.form("email_form"):
        teacher_email = st.text_input("Teacher Email")
        parent_Subject = st.text_input("Subject")
        reportcard = st.file_uploader("Upload Student Report Card",type=["pdf"])
        
        submitted = st.form_submit_button("📤 Send Email")

    if submitted:
        if not teacher_email:
            st.error("Please enter a recipient email.")
        elif not parent_Subject:
            st.error("Please enter a subject.")
        elif reportcard is None:
            st.error("Please upload a PDF file.")
        else:
            try:
                with st.spinner("Sending email..."):
                    guid = uuid.uuid4()

                    student_data = {
                        "CaseId": "GS-" + str(guid).split("-")[0],
                        "CaseType": concern_type,
                        "CaseDescription": description,
                        "StudentAdmissionNumber": child_id              
                    }

                    result = create_entity_record(tokenVal, student_data,"CaseManagement")

                    msg = MIMEMultipart()
                    msg["From"]    = SENDER_EMAIL
                    msg["To"]      = teacher_email
                    msg["Subject"] = parent_Subject
                    msg.attach(MIMEText(description, "plain"))

                    attachment = MIMEBase("application", "octet-stream")
                    attachment.set_payload(reportcard.read())
                    encoders.encode_base64(attachment)
                    attachment.add_header(
                        "Content-Disposition",
                        f"attachment; filename={reportcard.name}"
                    )
                    msg.attach(attachment)

                    with smtplib.SMTP("smtp.gmail.com", 587) as server:
                        server.starttls()
                        server.login(SENDER_EMAIL, SENDER_PASSWORD)
                        server.sendmail(SENDER_EMAIL, teacher_email, msg.as_string())

                st.success(f"Email sent successfully to **{teacher_email}**!")                

            except smtplib.SMTPAuthenticationError:
                st.error("Authentication failed. Check your credentials in Credential Manager.")
            except Exception as e:
                st.error(f"Error: {e}")

# SAFETY
elif concern_type == "Safety":

    with st.form("safety_form"):
        st.subheader("Digital Safety Details")

        student_email = st.text_input("Student Email")

        incident_type = st.selectbox(
            "Incident Type",
            [
                "Cyberbullying",
                "Unsafe Content",
                "Excessive Screen Time",
                "Unknown"
            ]
        )

        screenshot = st.file_uploader(
            "Upload Screenshot",
            type=["png", "jpg", "jpeg", "pdf"],
            accept_multiple_files=False
        )

        submitted_safety = st.form_submit_button("Send Details")
    
    if submitted_safety:
        with st.spinner("Sending details..."):
            guid = uuid.uuid4()

            student_data = {
                "CaseId": "GS-" + str(guid).split("-")[0],
                "CaseType": concern_type,
                "CaseDescription": description,
                "StudentAdmissionNumber": child_id,
                "Skills": "na",
                "Interest": "na",
                "StudentEmail": student_email         
            }

            result = create_entity_record(tokenVal, student_data,"CaseManagement")
            result_1 = get_EntityRecord_Id(tokenVal,"CaseManagement",student_email)
            
            record_id = result_1[0]["Id"]
            
            upload_result_safety = upload_entity_file(
            record_id,
            tokenVal,
            screenshot,
            "IncidentProof"
            )
            
        st.success(f"Details sent successfully.")    

# CAREER
elif concern_type == "Career":
 
    with st.form("email_form"):
        st.subheader("Career Guidance Details")
 
        student_email = st.text_input("Student Email")
 
        interests = st.multiselect(
            "Select Interests",
            [
                "AI",
                "Programming",
                "Medicine",
                "Engineering",
                "Design",
                "Business",
                "Arts",
                "Sports"
            ]
        )
 
        skills = st.multiselect(
            "Skills",
            [
                "Python",
                "Communication",
                "Problem Solving",
                "Leadership",
                "Creativity"
            ]
        )
 
        report_card = st.file_uploader(
            "Upload Report Card",
            type=["pdf","Docx"],
            accept_multiple_files=False
        )
 
        certificates = st.file_uploader(
            "Upload Certificates",
            type=["pdf", "jpg", "png"],
            accept_multiple_files=False
        )
       
        submitted_career = st.form_submit_button("Send Details")
 
    if submitted_career:
        with st.spinner("Sending details..."):
            guid = uuid.uuid4()
 
            student_data = {
                "CaseId": "GS-" + str(guid).split("-")[0],
                "CaseType": concern_type,
                "CaseDescription": description,
                "StudentAdmissionNumber": child_id,
                "Skills": skills,
                "Interest": interests,
                "StudentEmail": student_email        
            }
 
            result = create_entity_record(tokenVal, student_data,"CaseManagement")
           
         
            record_id=result["Id"]
            #result_1 = get_EntityRecord_Id(tokenVal,"CaseManagement",student_email)
           
            #record_id = result_1["value"][student_email]["Id"]
            print(record_id)
           # Upload Report Card
 
            if report_card is not None:
 
                upload_entity_file(
                    record_id,
                    tokenVal,
                    report_card,
                    "ReportCard"
                )
 
            # Upload Certificate
 
            if certificates is not None:
 
                upload_entity_file(
                    record_id,
                    tokenVal,
                    certificates,
                    "Certificates"
                )
                       
        st.success(f"Details sent successfully.")    