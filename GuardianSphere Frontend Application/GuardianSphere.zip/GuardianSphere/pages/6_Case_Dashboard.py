
import streamlit as st, pandas as pd
st.title("Case Dashboard")
st.dataframe(pd.DataFrame(columns=["CaseId","Type","Status","RiskScore"]))
