
import streamlit as st
st.title("Assessment Upload")
st.text_input("Child ID")
st.number_input("Math Score",0,100)
st.number_input("Science Score",0,100)
st.number_input("Attendance %",0,100)
st.button("Run Assessment")
