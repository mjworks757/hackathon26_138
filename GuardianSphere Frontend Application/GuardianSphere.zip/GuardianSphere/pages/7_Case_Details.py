
import streamlit as st
st.title("Case Details")
st.text_input("Case ID")
st.write("Case details and agent recommendations appear here.")
