import streamlit as st
import requests

st.title("Child Registration")

with st.form("child"):

    name = st.text_input("Name")
    age = st.number_input("Age",0,18,10)
    grade = st.text_input("Grade")
    school = st.text_input("School")

    submitted = st.form_submit_button("Save")

    if submitted:

        payload = {
            "name": name,
            "age": age,
            "grade": grade,
            "school": school
        }

        response = requests.post(
            "http://localhost:8501/register-child",
            json=payload
        )
        print(f"Status: {response.status_code}")
        print(f"Response: {response.text}")
       # st.write(response.status_code)
        #st.write(response.json())
        #st.write("Status:", response.status_code)
        #st.write("Response:", response.text)
        f"Child Registered Successfully"