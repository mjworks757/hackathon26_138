
import streamlit as st
st.title("Human Review (Action Center Demo)")
st.text_area("Recommendation")
st.selectbox("Decision",["Approve","Reject","Request More Info"])
st.button("Submit Decision")
