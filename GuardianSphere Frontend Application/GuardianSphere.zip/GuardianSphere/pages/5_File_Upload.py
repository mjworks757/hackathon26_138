
import streamlit as st
st.title("Document Upload")
f=st.file_uploader("Upload reports", type=None)
if f:
    st.success(f"Uploaded: {f.name}")
