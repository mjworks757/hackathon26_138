
import streamlit as st
st.set_page_config(page_title="GuardianSphere AI", layout="wide")
st.title("GuardianSphere AI")
st.write("Use the left sidebar to navigate between modules.")
