import requests
import json

def start_register_child(data):

    token = "LESIywWa%Ytk)FpM5EOGR8CFJIJPU#bxUBx3ZgJkEy5h^Jy^WDOIF!x)SwFUBsev"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    payload = {
        "startInfo": {
            "ReleaseKey": "1840c348-38e1-418f-841f-166bcd080046",
            "Strategy": "ModernJobsCount",
            "JobsCount": 1,
            "InputArguments": json.dumps({
                "in_Name": data["Name"],
                "in_Age": data["age"],
                "in_Grade": data["grade"],
                "in_School": data["school"]
            })
        }
    }

    response = requests.post(
        "https://staging.uipath.com/hackathon26_138/DefaultTenant/orchestrator_/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs",
        headers=headers,
        json=payload
    )

    return response.json()
