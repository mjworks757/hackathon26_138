from fastapi import FastAPI

app = FastAPI()

'''@app.post("/register-child")
async def register_child(data: dict):

    print(data)

    return {
        "status": "received"
    }

@app.post("/create-case")
async def create_case(data: dict):

    print(data)

    return {
        "status":"case-created"
    }'''


@app.post("/register-child")
async def register_child(data: dict):

    result = start_register_child(data)

    return {
        "status":"submitted",
        "job":result
    }
   