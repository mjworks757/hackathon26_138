import sys
import os
import uuid

sys.path.append(os.path.join(os.path.dirname(__file__), "UiPath"))

from UiPath.uipath_token import get_uipath_token
# from UiPath.uipath_entities import create_entity_record
from UiPath.uipath_entities import get_EntityRecord_Id
# from UiPath.uipath_entities import upload_entity_file
# from UiPath.uipath_entities import upload_entity_proof_file

if __name__ == "__main__":
    tokenVal = get_uipath_token("049bec0a-d959-46ad-8bf1-6a790b70802d","drUU6ZrF^~hk09C5tbc%2%jkUs7?t9Mo#nq69yYC?*8R)scZw^xGXmuVs(@$uo7S","DataFabric.Data.Read DataFabric.Data.Write DataFabric.Schema.Read")
    print("Token:", tokenVal)

    guid = uuid.uuid4()

    student_data = {
        "CaseId": "GS-" + str(guid).split("-")[0],
        "CaseType": "Test",
        "CaseDescription": "Test Desc",
        "StudentAdmissionNumber": "Test1"              
    }
    
    # result = create_entity_record(tokenVal, student_data,"CaseManagement")
    # print("Created Record:", result)
    result = get_EntityRecord_Id(tokenVal,"CaseManagement","mohit.codeboticsschool@gmail.com")
    record_id = result[0]["Id"]
    print(record_id)
    # upload_result = upload_entity_file_testing(
    # record_id,
    # tokenVal,
    # r"D:\UiPathAgentHack2026\Frontend\input\Student_Report_Card.pdf"
    # )

    