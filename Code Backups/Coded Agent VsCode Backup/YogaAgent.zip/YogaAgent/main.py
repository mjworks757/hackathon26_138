import asyncio
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import START, StateGraph, END
import traceback
import json

from uipath_langchain.chat import (
    UiPathAzureChatOpenAI,
)
from pydantic import BaseModel

class GraphState(BaseModel):
    wellness_goal: str

class GraphOutput(BaseModel):
    daily_yoga_plan: str


async def generate_yoga_plan(state: GraphState) -> GraphOutput:        
    try:
        print("Creating model...")
        llm = UiPathAzureChatOpenAI(model="gpt-4.1-mini-2025-04-14")
        print("Model created")
    except Exception:
        traceback.print_exc()

    system_prompt = """
    You are a certified children's yoga and wellness coach.

    Generate a daily wellness recommendation suitable for children.

    Include:
    1. One yoga pose.
    2. One breathing exercise.
    3. One wellness tip.
    4. A suggestion for a short yoga or wellness video topic for parents.

    Keep the response concise, safe, positive, and child-friendly.
    """

    user_prompt = f"""
    Wellness Goal:
    {state.wellness_goal}
    """

    output = await llm.ainvoke(
        [
            SystemMessage(system_prompt),
            HumanMessage(user_prompt)
        ]
    )

    return GraphOutput(
        daily_yoga_plan=output.content
    )


# Build Graph
builder = StateGraph(
    GraphState,
    output=GraphOutput
)

builder.add_node(
    "generate_yoga_plan",
    generate_yoga_plan
)

builder.add_edge(
    START,
    "generate_yoga_plan"
)

builder.add_edge(
    "generate_yoga_plan",
    END
)

graph = builder.compile()
print(graph.get_graph().draw_mermaid())

if __name__ == "__main__":   
    with open("input.json", "r") as f:
        data = json.load(f)

    input_state = GraphState(**data)

    result = asyncio.run(graph.ainvoke(input_state))
    print(result["daily_yoga_plan"])